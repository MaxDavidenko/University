package com.horstmann.violet.product.diagram.state.edge;

import com.horstmann.violet.framework.injection.resources.ResourceBundleConstant;
import com.horstmann.violet.framework.util.BeanInfo;

/**
 * TODO javadoc
 * This ...
 *
 * @author Adrian Bobrowski <adrian071993@gmail.com>
 * @date 20.03.2016
 */
public class StateTransitionEdgeBeanInfo extends BeanInfo
{
    public StateTransitionEdgeBeanInfo()
    {
        super(StateTransitionEdge.class);
    }
}

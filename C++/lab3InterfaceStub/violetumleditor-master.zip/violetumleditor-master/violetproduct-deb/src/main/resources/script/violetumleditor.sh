#!/bin/sh
java -jar /usr/share/violetumleditor/violetumleditor.jar

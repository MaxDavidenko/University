#!/bin/sh
java -jar com.horstmann.violet.jar

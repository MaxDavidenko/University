package com.horstmann.violet.framework.graphics.content;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * This ...
 *
 * @author Adrian Bobrowski
 * @date 13.01.2016
 */
public class LayoutTest {

    @Test
    public void testAdd() throws Exception {

    }

    @Test
    public void testRemove() throws Exception {

    }

    @Test
    public void testGetSeparator() throws Exception {

    }

    @Test
    public void testSetSeparator() throws Exception {

    }

    @Test
    public void testGetLocation() throws Exception {

    }
}
package com.horstmann.violet.workspace.sidebar.colortools;

public interface IColorChoiceChangeListener
{

    public void onColorChoiceChange(ColorChoice newColorChoice);
    
}

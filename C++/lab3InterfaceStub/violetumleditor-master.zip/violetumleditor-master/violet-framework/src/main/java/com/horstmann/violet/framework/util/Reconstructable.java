package com.horstmann.violet.framework.util;

/**
 * TODO javadoc
 * This ...
 *
 * @author Adrian Bobrowski <adrian071993@gmail.com>
 * @date 13.03.2016
 */
public interface Reconstructable
{
    void reconstruction();
}

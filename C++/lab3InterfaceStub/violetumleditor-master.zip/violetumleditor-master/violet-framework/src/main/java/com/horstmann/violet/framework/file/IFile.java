package com.horstmann.violet.framework.file;

public interface IFile
{

    public abstract String getFilename();

    public abstract String getDirectory();

}
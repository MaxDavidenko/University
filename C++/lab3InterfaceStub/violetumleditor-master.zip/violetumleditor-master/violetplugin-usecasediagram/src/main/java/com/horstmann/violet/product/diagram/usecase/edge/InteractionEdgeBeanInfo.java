package com.horstmann.violet.product.diagram.usecase.edge;

/**
 * TODO javadoc
 * This ...
 *
 * @author Adrian Bobrowski <adrian071993@gmail.com>
 * @date 20.03.2016
 */
public class InteractionEdgeBeanInfo {
}

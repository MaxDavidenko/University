#ifndef REFACTOR_H
#define REFACTOR_H

#include <QString>


class Refactor {  
private:
    bool isNameOfVariable(QChar ch) const;
public:
    Refactor();
    
    QString rename(QString sourceCode, QString sourceVar, QString resultVar);
    QString align(QString sourceCode);
};

#endif // REFACTOR_H
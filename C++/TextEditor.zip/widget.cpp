#include "widget.h"
#include "ui_widget.h"
#include "D:\\OneDrive\QtCreator\UTTextEditor\refactor.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_buttonRename_clicked()
{
    Refactor renamer;
    ui->teditSourceCode->setText(renamer.rename(ui->teditSourceCode->toPlainText(), ui->leditSourseVar->text(), ui->leditResultVar->text()));
}

#include "refactor.h"

Refactor::Refactor() {
    
}

bool Refactor::isNameOfVariable(QChar ch) const {
    return ((ch >= QChar('a') && ch <= QChar('z')) || (ch >= QChar('A') && ch <= QChar('Z')) || ch == QChar('_') || (ch >= QChar('0') && ch <= QChar('9')));
}

QString Refactor::rename(QString sourceCode, QString sourceVar, QString resultVar) {
    for(int i = 0, j = 0, lenght = sourceCode.length(); i < lenght; ++i) {
        if(sourceCode[i] == '/' && sourceCode[i + 1] == '/') {
            for(; sourceCode[i] != '\n' && i < lenght; ++i);
        }
        
        if(sourceCode[i] == '/' && sourceCode[i + 1] == '*') {
            for(; sourceCode[i] != '*' && sourceCode[i + 1] == '/' && i < lenght; ++i);
        }
        
        if(sourceCode[i] == sourceVar[j]) {
            j++;
            if(j == sourceVar.length()) {
                if((i + 1 < lenght || i - j >= 0 ? !isNameOfVariable(sourceCode[i + 1]) : true) 
                     && (i - j < 0 ? true : !isNameOfVariable(sourceCode[i - j]))) {
                    i -= sourceVar.length() - 1;
                    sourceCode.remove(i, sourceVar.length());
                    sourceCode.insert(i, resultVar);
                    }
                j = 0;
            }    
        }
        else j = 0;
    }
    return sourceCode;
}

QString Refactor::align(QString sourceCode) {
    return sourceCode;
}

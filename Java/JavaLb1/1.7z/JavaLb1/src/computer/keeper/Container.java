/**
 * package have contained interface for container class
 */
package computer.keeper;

import java.util.Iterator;

/**
 * @author max
 * @version 1.0
 */
public interface  Container<T> {

    /**
     *
     * @return size of container
     */
    public int size();

    /**
     *
     * @return  empty state of container
     *
     */
    public  boolean isEmpty();
    /**
     * remove all container data
     */
    public void clear();

    public void set(T obj);

    public Object[] getList();
}

/**
 * this package have contained a class which describe
 * a container for Objects
 */
package computer.keeper;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author max
 * @version 1.0
 * @param <T> generic object
 */
public class ComputerKeeper<T> implements Container, Iterable<T> {

    /**
     * @value keeper it is java collection type*/
    private ArrayList<T> keeper;

    /**
     * constructor for class-container
     * */
    public ComputerKeeper() {
        keeper = new ArrayList<T>();
    }
    @Override
    public final int size() {
        return keeper.size();
    }

    /**
     *
     * @param index - index of element which we want to get
     * @return
     */
    public final T get(final int index) {
        if (index > keeper.size())
            throw new IndexOutOfBoundsException();
        return keeper.get(index);
    }
    /**
     *
     * @param obj have info about some object
     */
    public final void add(T obj) {
        this.keeper.add(obj);
    }
    @Override
    public final void set(final T obj) {
        this.keeper.add((T) obj);
    }

    /**
     *
     * @return an itetator on object
     */
    public final Iterator iterator() {
        return this.keeper.iterator();
    }


    @Override
    public final Object[] getList() {
        return keeper.toArray();
    }

    @Override
    public final boolean isEmpty() {
        return this.keeper.isEmpty();
    }

    @Override
    public final void clear() {
        this.keeper.clear();
    }



}

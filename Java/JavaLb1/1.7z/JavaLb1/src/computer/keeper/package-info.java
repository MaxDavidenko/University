/**
 * computer.keeper package have contained an
 * interface for container class.
 * Also this package contain class ComputerKeeper which
 * described implementation  of class Container.
 */
package computer.keeper;

/**
 * package have a class for test a lab 1 for java.
 */
package computer;
